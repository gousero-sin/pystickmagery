# goflow-core

Nucleo reutilizavel do GoFlowOS para React, com foco visual em **Liquid Glass dark-first**.

## O que este pacote entrega

- Superficies Liquid Glass com fallback robusto (`GlacierGlassSurface`, `LiquidGlassSurface`)
- Painel Glacier com **metricas reais do navegador** (sem placeholders): `GlacierFS`
- Loaders animados (`LiquidIntelligenceLoader`, `LiquidDbConnectionLoader`)
- Hook de telemetria real: `useBrowserPerformanceMetrics`
- Hook de suporte visual: `useGlacierGlassSupport`
- Sistema de tema travado em dark mode no `ThemeProvider`

## Instalacao

```bash
npm install goflow-core
```

Ou instalacao local via pacote `.tgz`:

```bash
npm install ./goflow-core-1.2.0.tgz
```

## CSS

Se o bundler nao injetar automaticamente o CSS da lib:

```js
import "goflow-core/styles.css";
```

## Uso rapido: Glacier com metricas reais

```jsx
import { ThemeProvider, GlacierFS } from "goflow-core";

function App() {
  return (
    <ThemeProvider>
      <GlacierFS />
    </ThemeProvider>
  );
}
```

O painel usa `web-vitals` + `PerformanceObserver` + sinais de runtime e rede quando disponiveis.
Cada sinal agora possui `value`, `unit`, `rating`, `status`, `reason`, sem placeholders numericos.

## Uso rapido: glass premium + fallback

```jsx
import { GlacierGlassCard } from "goflow-core";

function MetricCard() {
  return (
    <GlacierGlassCard>
      <h3>Live runtime</h3>
      <p>Liquid glass nativo quando suportado, fallback CSS quando necessario.</p>
    </GlacierGlassCard>
  );
}
```

## Uso rapido: controle de loader

```jsx
import {
  ThemeProvider,
  LiquidIntelligenceLoader,
  useLiquidLoaderController
} from "goflow-core";

function Example() {
  const loader = useLiquidLoaderController();

  const runTask = () => {
    loader.show(0);
    setTimeout(() => loader.hide(), 2400);
  };

  return (
    <ThemeProvider>
      <button onClick={runTask}>Executar</button>
      <LiquidIntelligenceLoader
        visible={loader.visible}
        exiting={loader.exiting}
        scene={loader.scene}
      />
    </ThemeProvider>
  );
}
```

## Demo local (core + demo alinhados)

Este repo agora inclui uma demo consumidora em `demo/`.

```bash
npm run dev:demo
```

Para conectar a demo ao backend:

```bash
VITE_GOFLOW_BACKEND_URL=http://127.0.0.1:8787 npm run dev:demo
```

Build da demo:

```bash
npm run build:demo
```

## Backend local (Glacier telemetry API)

Este repo agora inclui um backend leve em Node HTTP em `backend/` com padrao em camadas
(`controller -> service -> repository`) para sessoes e metricas de telemetria.

Subir backend:

```bash
npm run backend:start
```

Modo dev (watch):

```bash
npm run backend:dev
```

Rodar testes backend:

```bash
npm run backend:test
```

Endpoints principais:

- `GET /api/health`
- `GET /api/glacier/sessions`
- `POST /api/glacier/sessions`
- `GET /api/glacier/sessions/:sessionId`
- `POST /api/glacier/sessions/:sessionId/metrics`
- `POST /api/glacier/sessions/:sessionId/snapshots`
- `GET /api/glacier/sessions/:sessionId/latest`
- `GET /api/glacier/sessions/:sessionId/summary?windowMinutes=15`

Para proteger escrita, defina `BACKEND_API_KEY` e envie `x-api-key` nas rotas `POST`.

Persistencia:

- Backend usa SQLite local por padrao em `backend/data/glacier.db`
- Customize via `BACKEND_DB_PATH=/caminho/custom.db`

CORS:

- `BACKEND_ALLOWED_ORIGIN` controla a origem permitida para chamadas browser (padrao `*`)
- `OPTIONS` preflight ativo para rotas `/api/*`

Variaveis da demo:

- `VITE_GOFLOW_BACKEND_ENABLED` (`false` para desligar bridge)
- `VITE_GOFLOW_BACKEND_URL`
- `VITE_GOFLOW_BACKEND_API_KEY`

## Scripts

- `npm run build` - build da lib
- `npm run test` - testes unitarios (Vitest)
- `npm run dev:demo` - demo local
- `npm run build:demo` - build da demo
- `npm run backend:start` - inicia backend HTTP
- `npm run backend:dev` - backend em modo watch
- `npm run backend:test` - testes backend (Node test runner)

## Compatibilidade visual

- `liquid-glass-react` funciona melhor em Chromium
- Safari/Firefox podem ter suporte parcial para deslocamento/refracao
- O pacote faz fallback para CSS glass mantendo legibilidade e contraste
